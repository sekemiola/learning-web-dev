
Hello!


Thank you for downloading our fonts. 

This font is for PERSONAL USE only. If you want full glyphs and commercial use, you can buy at patriastd.com

--------------------------------------------------------------
Discount Up to 75% for selected products only on patriastd.com
--------------------------------------------------------------

Thank you